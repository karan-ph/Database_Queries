"""
-------------------------------------------------------
functions.py
CP363 Assignment 2.
-------------------------------------------------------
Author: Karan Hayer
ID:     200373590
Email:  haye3590@mylaurier.ca
__updated__ = "2022-10-28"
"""

def get_member_publications(cursor, pubTitle=None, pubType=None):
    """
    -------------------------------------------------------
    Queries the pub and member tables.
    Use: rows = get_member_publications(cursor)
    Use: rows = get_member_publications(cursor, pubTitle=v1)
    Use: rows = get_member_publications(cursor, pubType=v2)
    Use: rows = get_member_publications(cursor, pubTitle=v1, pubType=v2)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        pubTitle - a partial pubTitle (str)
        pubType - a publication type (str)
    Returns:
        rows - (list of member's last name, member's first
            name, the title of a publication, and the full publication
            type (i.e. 'article' rather than 'a') data)
            if pubTitle and/or pubType are not None:
                rows containing pubTitle and/or pubType
            else:
                all member and publication rows
            Sorted by last name, first name, publication title
    -------------------------------------------------------
    """
    if pubType != None and pubTitle != None:
        value = """SELECT memberSurname, memberForename, pubPubType, pubTitle FROM member 
            INNER JOIN pub ON (pubMemberId = memberId)
            WHERE pubPubType = %(pubPubType)s AND pubTitle = %(pubTitle)s
            ORDER BY memberSurname,memberForename, pubTitle
        """
        params = {'pubTitle':pubTitle, 'pubPubType':pubType}
        cursor.execute(value,params)
    elif pubType == None:
        value = """SELECT memberSurname, memberForename, pubPubType, pubTitle FROM member 
            INNER JOIN pub ON (pubMemberId = memberId)
            WHERE pubTitle = %(pubTitle)s
            ORDER BY memberSurname,memberForename, pubTitle
        """
        params = {'pubTitle':pubTitle}
        cursor.execute(value,params)
    
    elif pubTitle == None:
        value = """SELECT memberSurname, memberForename, pubPubType, pubTitle FROM member 
            INNER JOIN pub ON (pubMemberId = memberId)
            WHERE pubPubType = %(pubPubType)s
            ORDER BY memberSurname,memberForename, pubTitle
        """
        params =  {'pubPubType':pubType}
        cursor.execute(value,params)
    
    else: 
        value = """SELECT memberSurname, memberForename, pubPubType, pubTitle FROM member 
            INNER JOIN pub ON (pubMemberId = memberId)
            ORDER BY memberSurname,memberForename, pubTitle
        """
        cursor.execute(value)
        
    rows = cursor.fetchall()
    
    return rows 

def get_publication_counts(cursor, memberId=None, pubType=None):
    """
    -------------------------------------------------------
    Queries the pub and member tables.
    Use: rows = get_publication_counts(cursor)
    Use: rows = get_publication_counts(cursor, memberId=v1)
    Use: rows = get_publication_counts(cursor, pubType=v2)
    Use: rows = get_publication_counts(cursor, memberId=v1, pubType=v2)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        memberId - a member ID number (int)
        pubType - a publication type (str)
    Returns:
        rows - (list of member's last name, member's first
            name, and the number of publications of type
            pubType data)
            if memberId or pubType is not None:
                rows containing memberId and/or pubType
            else:
                all member names and publication counts
            Sorted by last name, first name
    -------------------------------------------------------
    """
    if pubType != None and memberId != None:
        value = """SELECT memberSurname, memberForename, 
            (SELECT COUNT(*) FROM pub WHERE pubMemberId = %(memberId)s AND pubPubType = %(pubPubType)s) AS pubCount FROM member 
            WHERE memberId = %(memberId)s 
            ORDER BY memberSurname,memberForename
        """
        params = {'memberId':memberId,'pubPubType':pubType}
        cursor.execute(value,params)
   
    elif pubType == None:
        value = """SELECT memberSurname, memberForename, 
            (SELECT COUNT(*) FROM pub WHERE pubMemberId = %(memberId)s) AS pubCount FROM member 
            WHERE memberId = %(memberId)s 
            ORDER BY memberSurname,memberForename
        """
        params = {'memberId':memberId}
        cursor.execute(value,params)
    else: 
        value = """SELECT memberSurname, memberForename, 
            (SELECT COUNT(*) FROM pub WHERE pubMemberId = memberId) AS pubCount FROM member 
            ORDER BY memberSurname,memberForename
        """
        cursor.execute(value)
        
    rows = cursor.fetchall()
    
    return rows 
    
    

def get_broad_counts(cursor, memberId=None):
    """
    -------------------------------------------------------
    Queries the member and broad tables.
    Use: rows = get_broad_counts(cursor)
    Use: rows = get_broad_counts(cursor, memberId=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        memberId - a member ID number (int)
    Returns:
        rows - (list of member's last name, member's first
            name, and the number of broad expertises they hold data)
            if memberId is not None:
                rows containing memberId
            else:
                all member and broad expertise rows
            Sorted by last name, first name
    -------------------------------------------------------
    """
    if memberId != None:
        value = """SELECT memberSurname, memberForename, 
            (SELECT COUNT(*) FROM memberBroad WHERE memberId = memberBroadMemberId) AS expertCount FROM member 
            WHERE memberId = %(memberId)s 
            ORDER BY memberSurname,memberForename
        """
        params = {'memberId':memberId}
        cursor.execute(value,params)
   
    
    else: 
        value = """SELECT memberSurname, memberForename, 
            (SELECT COUNT(*) FROM memberBroad WHERE memberId = memberBroadMemberId) AS expertCount FROM member 
            ORDER BY memberSurname,memberForename
        """
        cursor.execute(value)
        
    rows = cursor.fetchall()
    
    return rows 
    
    


def get_all_expertises(cursor, memberId=None):
    """
    -------------------------------------------------------
    Queries the member, broad, and narrow tables
    Use: rows = get_all_expertises(cursor)
    Use: rows = get_all_expertises(cursor, memberId=v1)
    -------------------------------------------------------
    Parameters:
        cursor - a database cursor (cursor)
        memberId - a member ID number (int)
    Returns:
        rows - (list of member's last name, member's first
            name, a broad description, and a narrow description data)
            if memberId is not None:
                rows containing memberId
            else:
                all member and expertise rows
            Sorted by last name, first name, broad description, narrow
                description
    -------------------------------------------------------
    """
    if memberId != None:
        value = """SELECT memberSurname, memberForename, broadDesc, narrowDesc
            FROM member 
            INNER JOIN memberBroad ON (memberId = memberBroadMemberId)
            INNER JOIN broad ON (broadId = memberBroadBroadId)
            INNER JOIN memberNarrow ON (memberId = memberNarrowMemberId)
            INNER JOIN narrow ON (narrowId = memberNarrowNarrowId)
            WHERE memberId = %(memberId)s
            ORDER BY memberSurname,memberForename
        """
        params = {'memberId':memberId}
        cursor.execute(value,params)
   
    
    else: 
        value = """SELECT memberSurname, memberForename, broadDesc, narrowDesc
            FROM member 
            INNER JOIN memberBroad ON (memberId = memberBroadMemberId)
            INNER JOIN broad ON (broadId = memberBroadBroadId)
            INNER JOIN memberNarrow ON (memberId = memberNarrowMemberId)
            INNER JOIN narrow ON (narrowId = memberNarrowNarrowId)
            ORDER BY memberSurname,memberForename
        """
        cursor.execute(value)
        
    rows = cursor.fetchall()
    
    return rows 
    