"""
-------------------------------------------------------
t03.py
CP363 Assignment 2.
-------------------------------------------------------
Author: Karan Hayer
ID:     200373590
Email:  haye3590@mylaurier.ca
__updated__ = "2022-10-28"
"""


from Connect import Connect
from functions import get_broad_counts


conn = Connect('dcris.txt')
cursor = conn.cursor

print("test get_broad_counts")
print()
r = get_broad_counts(cursor, 42)
print(r)
